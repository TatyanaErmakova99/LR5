public class Figure {
    public void drow() {
        System.out.println("FIGURE");
    }
    public int getPiecesOfFigure() {   //метод, который возвращает количество фигур
        return 8;
    }
}
