public class NewFigure extends Figure {
    public int getPiecesOfFigure() {   //метод, который возвращает количество фигур
        return 5;
    }
}